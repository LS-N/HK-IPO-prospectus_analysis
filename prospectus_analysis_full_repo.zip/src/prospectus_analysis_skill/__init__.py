
from .skill import ProspectusAnalysisSkill
